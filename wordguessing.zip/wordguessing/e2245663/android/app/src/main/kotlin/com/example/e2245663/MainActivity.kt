package com.example.e2245663

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
